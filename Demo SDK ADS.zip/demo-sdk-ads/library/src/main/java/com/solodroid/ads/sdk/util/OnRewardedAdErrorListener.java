package com.solodroid.ads.sdk.util;

public interface OnRewardedAdErrorListener {
    void onRewardedAdError();
}