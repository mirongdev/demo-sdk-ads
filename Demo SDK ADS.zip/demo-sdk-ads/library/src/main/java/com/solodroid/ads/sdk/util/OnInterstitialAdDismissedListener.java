package com.solodroid.ads.sdk.util;

public interface OnInterstitialAdDismissedListener {
    void onInterstitialAdDismissed();
}