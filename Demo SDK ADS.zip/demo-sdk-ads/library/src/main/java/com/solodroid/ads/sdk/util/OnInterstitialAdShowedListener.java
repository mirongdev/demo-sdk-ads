package com.solodroid.ads.sdk.util;

public interface OnInterstitialAdShowedListener {
    void onInterstitialAdShowed();
}