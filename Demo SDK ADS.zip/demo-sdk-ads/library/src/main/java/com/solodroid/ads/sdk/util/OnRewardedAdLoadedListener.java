package com.solodroid.ads.sdk.util;

public interface OnRewardedAdLoadedListener {
    void onRewardedAdLoaded();
}